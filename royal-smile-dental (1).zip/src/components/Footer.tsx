import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Instagram, Facebook, Twitter, ExternalLink, MessageCircle } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="flex flex-col gap-6">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-medical-primary rounded-lg flex items-center justify-center text-white font-bold text-xl">
                R
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-lg leading-tight text-white text-left">Royal Smile</span>
                <span className="text-xs text-medical-primary font-medium uppercase tracking-wider text-left">Dental Clinic</span>
              </div>
            </Link>
            <p className="text-sm leading-relaxed text-slate-400">
              Providing top-rated dental care in Paschim Vihar, West Delhi. Our mission is to give you a healthy, beautiful smile with the latest technology and compassionate care.
            </p>
            <div className="flex items-center gap-4">
              <a 
                href="https://wa.me/917838406641" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-[#25D366] hover:text-white transition-colors"
                aria-label="WhatsApp"
              >
                <MessageCircle size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-medical-primary hover:text-white transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-medical-primary hover:text-white transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-medical-primary hover:text-white transition-colors">
                <Twitter size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-display font-bold mb-6">Quick Links</h3>
            <ul className="flex flex-col gap-4 text-sm">
              <li><Link to="/" className="hover:text-medical-primary transition-colors">Home</Link></li>
              <li><Link to="/about" className="hover:text-medical-primary transition-colors">About Us</Link></li>
              <li><Link to="/services" className="hover:text-medical-primary transition-colors">Our Services</Link></li>
              <li><Link to="/booking" className="hover:text-medical-primary transition-colors">Book Appointment</Link></li>
              <li><Link to="/contact" className="hover:text-medical-primary transition-colors">Contact Us</Link></li>
              <li><a href="https://www.google.com/search?q=Royal+Smile+Dental+Paschim+Vihar#lrd=0x390d037666666667:0x6666666666666666,1" target="_blank" rel="noopener noreferrer" className="hover:text-medical-primary transition-colors">Google Reviews</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-display font-bold mb-6">Our Services</h3>
            <ul className="flex flex-col gap-4 text-sm">
              <li><Link to="/services" className="hover:text-medical-primary transition-colors">Root Canal Treatment (RCT)</Link></li>
              <li><Link to="/services" className="hover:text-medical-primary transition-colors">Dental Implants</Link></li>
              <li><Link to="/services" className="hover:text-medical-primary transition-colors">Wisdom Tooth Removal</Link></li>
              <li><Link to="/services" className="hover:text-medical-primary transition-colors">Dental Crowns & Bridges</Link></li>
              <li><Link to="/services" className="hover:text-medical-primary transition-colors">Teeth Cleaning & Polishing</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-display font-bold mb-6">Contact Us</h3>
            <ul className="flex flex-col gap-4 text-sm">
              <li className="flex gap-3">
                <MapPin className="text-medical-primary shrink-0" size={18} />
                <a 
                  href="https://maps.google.com/?q=Royal+Smile+Dental+Paschim+Vihar" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-medical-primary transition-colors"
                >
                  Paschim Vihar, West Delhi
                </a>
              </li>
              <li className="flex gap-3">
                <Phone className="text-medical-primary shrink-0" size={18} />
                <div className="flex flex-col">
                  <a href="tel:7838406641" className="hover:text-medical-primary transition-colors">78384 06641</a>
                  <a 
                    href="https://wa.me/917838406641" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-xs text-medical-secondary hover:underline flex items-center gap-1 mt-1"
                  >
                    <MessageCircle size={12} /> Chat on WhatsApp
                  </a>
                </div>
              </li>
              <li className="flex gap-3">
                <Mail className="text-medical-primary shrink-0" size={18} />
                <a href="mailto:shubhamshersiya99@gmail.com" className="hover:text-medical-primary transition-colors">shubhamshersiya99@gmail.com</a>
              </li>
              <li className="mt-2">
                <span className="text-xs font-medium text-slate-500 uppercase tracking-widest block mb-2">Working Hours</span>
                <p>Mon - Sat: 10:00 AM - 8:00 PM</p>
                <p>Sunday: Closed</p>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>© {currentYear} Royal Smile Dental Clinic. All rights reserved.</p>
          <div className="flex gap-6">
            <Link to="/privacy-policy" target="_blank" className="hover:text-medical-primary transition-colors flex items-center gap-1">
              Privacy Policy <ExternalLink size={12} />
            </Link>
            <Link to="/terms-conditions" target="_blank" className="hover:text-medical-primary transition-colors flex items-center gap-1">
              Terms & Conditions <ExternalLink size={12} />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
