import React from 'react';
import { MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';

const FloatingWhatsApp = () => {
  return (
    <motion.a
      href="https://wa.me/917838406641"
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow cursor-pointer"
      aria-label="Contact on WhatsApp"
    >
      <MessageCircle size={32} fill="currentColor" />
    </motion.a>
  );
};

export default FloatingWhatsApp;
