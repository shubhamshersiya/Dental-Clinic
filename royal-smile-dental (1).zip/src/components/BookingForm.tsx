import React, { useState } from 'react';
import { MessageCircle, Calendar, Clock, User, Phone, Stethoscope, Send } from 'lucide-react';
import { BookingData } from '../types';

interface BookingFormProps {
  title?: string;
  subtitle?: string;
  compact?: boolean;
}

const BookingForm: React.FC<BookingFormProps> = ({ 
  title = "Book Your Appointment", 
  subtitle = "Fill in the details below and we'll confirm your booking on WhatsApp.",
  compact = false 
}) => {
  const [formData, setFormData] = useState<BookingData>({
    fullName: '',
    phoneNumber: '',
    service: '',
    date: '',
    time: '',
    message: ''
  });

  const services = [
    'Root Canal Treatment (RCT)',
    'Dental Implants',
    'Wisdom Tooth Removal',
    'Dental Crowns & Bridges',
    'Teeth Cleaning & Polishing',
    'General Consultation',
    'Other'
  ];

  const timeSlots = [
    '10:00 AM', '11:00 AM', '12:00 PM', '01:00 PM', 
    '02:00 PM', '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM'
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const { fullName, phoneNumber, service, date, time, message } = formData;
    
    const whatsappMessage = `*New Appointment Request*
--------------------------
*Patient Name:* ${fullName}
*Phone:* ${phoneNumber}
*Service:* ${service}
*Preferred Date:* ${date}
*Preferred Time:* ${time}
*Symptoms/Message:* ${message || 'N/A'}
--------------------------
_Sent from Royal Smile Dental Website_`;

    const encodedMessage = encodeURIComponent(whatsappMessage);
    const whatsappUrl = `https://wa.me/917838406641?text=${encodedMessage}`;
    
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className={`bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden ${compact ? '' : 'max-w-2xl mx-auto'}`}>
      <div className="bg-medical-primary p-6 text-white">
        <h3 className="text-xl font-display font-bold mb-1">{title}</h3>
        <p className="text-sm text-white/80">{subtitle}</p>
      </div>
      
      <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Full Name */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <User size={16} className="text-medical-primary" />
              Full Name
            </label>
            <input
              required
              type="text"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Enter your full name"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-medical-primary focus:ring-2 focus:ring-medical-primary/20 outline-none transition-all"
            />
          </div>

          {/* Phone Number */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Phone size={16} className="text-medical-primary" />
              Phone Number
            </label>
            <input
              required
              type="tel"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleChange}
              placeholder="Enter mobile number"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-medical-primary focus:ring-2 focus:ring-medical-primary/20 outline-none transition-all"
            />
          </div>

          {/* Service */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Stethoscope size={16} className="text-medical-primary" />
              Select Service
            </label>
            <select
              required
              name="service"
              value={formData.service}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-medical-primary focus:ring-2 focus:ring-medical-primary/20 outline-none transition-all appearance-none bg-white"
            >
              <option value="" disabled>Choose a service</option>
              {services.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          {/* Date */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Calendar size={16} className="text-medical-primary" />
              Preferred Date
            </label>
            <input
              required
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              min={new Date().toISOString().split('T')[0]}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-medical-primary focus:ring-2 focus:ring-medical-primary/20 outline-none transition-all"
            />
          </div>

          {/* Time */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Clock size={16} className="text-medical-primary" />
              Preferred Time
            </label>
            <select
              required
              name="time"
              value={formData.time}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-medical-primary focus:ring-2 focus:ring-medical-primary/20 outline-none transition-all appearance-none bg-white"
            >
              <option value="" disabled>Select time slot</option>
              {timeSlots.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>

        {/* Message */}
        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700">
            Message / Symptoms (Optional)
          </label>
          <textarea
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="Tell us about your dental concern..."
            rows={3}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-medical-primary focus:ring-2 focus:ring-medical-primary/20 outline-none transition-all resize-none"
          />
        </div>

        <button type="submit" className="btn-primary w-full py-4 text-lg">
          <MessageCircle size={22} />
          Confirm via WhatsApp
        </button>
        
        <p className="text-center text-xs text-slate-400">
          By clicking submit, you'll be redirected to WhatsApp to send your request.
        </p>
      </form>
    </div>
  );
};

export default BookingForm;
