import React from 'react';
import { motion } from 'motion/react';
import { useModal } from '../context/ModalContext';
import { Calendar } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  hoverTitle?: string;
  description: string;
  image: string;
  delay?: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, hoverTitle, description, image, delay = 0 }) => {
  const { openBookingModal } = useModal();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      onClick={openBookingModal}
      className="group relative h-[450px] w-full rounded-[2.5rem] overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 cursor-pointer"
    >
      {/* Background Image */}
      <img 
        src={image} 
        alt={title} 
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        referrerPolicy="no-referrer"
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity duration-500" />

      {/* Glassmorphism Content Overlay (Visible on Hover) */}
      <div className="absolute inset-4 rounded-[2rem] bg-white/10 backdrop-blur-md border border-white/20 p-8 flex flex-col justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-4 group-hover:translate-y-0">
        <h4 className="text-white font-display font-bold text-xl mb-4 leading-tight">
          {hoverTitle || title}
        </h4>
        <p className="text-white/90 text-sm leading-relaxed">
          {description}
        </p>
        <div className="mt-8 flex items-center gap-2 text-white font-bold text-xs uppercase tracking-widest opacity-70 group-hover:opacity-100 transition-opacity">
          <Calendar size={14} className="text-medical-primary" />
          <span>Click to Book</span>
        </div>
      </div>

      {/* Bottom Title (Hidden on Hover) */}
      <div className="absolute bottom-8 left-0 right-0 text-center px-6 group-hover:opacity-0 transition-opacity duration-300">
        <h3 className="text-white font-display font-bold text-xl tracking-wide">
          {title}
        </h3>
      </div>
    </motion.div>
  );
};

export default ServiceCard;
