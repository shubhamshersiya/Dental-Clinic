import React from 'react';
import { Star, Quote } from 'lucide-react';

interface TestimonialCardProps {
  name: string;
  rating: number;
  text: string;
  date: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ name, rating, text, date }) => {
  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm relative">
      <Quote className="absolute top-6 right-8 text-slate-100" size={48} />
      
      <div className="flex gap-1 mb-4">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            size={16} 
            className={i < rating ? "fill-yellow-400 text-yellow-400" : "text-slate-200"} 
          />
        ))}
      </div>
      
      <p className="text-slate-600 italic mb-6 relative z-10">"{text}"</p>
      
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-bold text-slate-900">{name}</h4>
          <p className="text-xs text-slate-400">{date}</p>
        </div>
        <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 font-bold">
          {name.charAt(0)}
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;
