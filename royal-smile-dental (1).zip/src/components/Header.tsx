import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useModal } from '../context/ModalContext';

const Header = () => {
  const { openBookingModal } = useModal();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Contact', path: '/contact' },
    { name: 'Reviews', path: 'https://www.google.com/search?q=Royal+Smile+Dental+Paschim+Vihar#lrd=0x390d037666666667:0x6666666666666666,1', external: true },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-medical-primary rounded-lg flex items-center justify-center text-white font-bold text-xl">
            R
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-lg leading-tight text-slate-900">Royal Smile</span>
            <span className="text-xs text-medical-secondary font-medium uppercase tracking-wider">Dental Clinic</span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                link.external ? (
                  <a
                    key={link.name}
                    href={link.path}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-medium transition-colors hover:text-medical-primary text-slate-600"
                  >
                    {link.name}
                  </a>
                ) : (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`text-sm font-medium transition-colors hover:text-medical-primary ${
                      isActive(link.path) ? 'text-medical-primary' : 'text-slate-600'
                    }`}
                  >
                    {link.name}
                  </Link>
                )
              ))}
          <button 
            onClick={openBookingModal}
            className="btn-primary py-2 px-5 text-sm"
          >
            <MessageCircle size={18} />
            Book on WhatsApp
          </button>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-slate-900 p-2"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-slate-100 overflow-hidden"
          >
            <div className="container mx-auto px-4 py-6 flex flex-col gap-4">
              {navLinks.map((link) => (
                link.external ? (
                  <a
                    key={link.name}
                    href={link.path}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setIsOpen(false)}
                    className="text-lg font-medium py-2 text-slate-600"
                  >
                    {link.name}
                  </a>
                ) : (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setIsOpen(false)}
                    className={`text-lg font-medium py-2 ${
                      isActive(link.path) ? 'text-medical-primary' : 'text-slate-600'
                    }`}
                  >
                    {link.name}
                  </Link>
                )
              ))}
              <button 
                onClick={() => {
                  setIsOpen(false);
                  openBookingModal();
                }}
                className="btn-primary mt-2"
              >
                <MessageCircle size={20} />
                Book on WhatsApp
              </button>
              <div className="flex items-center gap-3 mt-4 pt-4 border-t border-slate-100 text-slate-500">
                <Phone size={18} />
                <span className="text-sm font-medium">78384 06641</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
