import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';
import { useModal } from '../context/ModalContext';
import BookingForm from './BookingForm';

const BookingModal = () => {
  const { isBookingModalOpen, closeBookingModal } = useModal();

  useEffect(() => {
    if (isBookingModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isBookingModalOpen]);

  return (
    <AnimatePresence>
      {isBookingModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeBookingModal}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl bg-white rounded-[32px] shadow-2xl overflow-hidden"
          >
            <button
              onClick={closeBookingModal}
              className="absolute top-6 right-6 z-10 p-2 bg-slate-100 text-slate-500 rounded-full hover:bg-medical-primary hover:text-white transition-all"
            >
              <X size={20} />
            </button>

            <div className="max-h-[90vh] overflow-y-auto">
              <BookingForm 
                title="Book Your Appointment" 
                subtitle="Fill the form and we'll confirm your slot on WhatsApp."
                compact
              />
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default BookingModal;
