import React from 'react';
import BookingForm from '../components/BookingForm';
import { Calendar, Clock, ShieldCheck, MessageCircle } from 'lucide-react';

const Booking = () => {
  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-20">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          {/* Left Side: Info */}
          <div className="flex-1 lg:sticky lg:top-32">
            <span className="text-medical-primary font-bold uppercase tracking-widest text-sm mb-4 block">Appointment</span>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-8 leading-tight">
              Book Your Visit to <span className="text-medical-primary">Royal Smile</span>
            </h1>
            
            <p className="text-lg text-slate-600 mb-10">
              We've made booking easy. Fill out the form, and our team will instantly receive your request on WhatsApp to confirm your slot.
            </p>
            
            <div className="space-y-8 mb-12">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center text-medical-primary shrink-0">
                  <Calendar size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Select Your Date</h4>
                  <p className="text-sm text-slate-500">Choose a day that works best for your schedule.</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center text-medical-primary shrink-0">
                  <Clock size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Pick a Time Slot</h4>
                  <p className="text-sm text-slate-500">We offer flexible hourly slots from 10 AM to 8 PM.</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center text-medical-primary shrink-0">
                  <MessageCircle size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">WhatsApp Confirmation</h4>
                  <p className="text-sm text-slate-500">Get instant confirmation and reminders on your phone.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-medical-primary/5 p-6 rounded-2xl border border-medical-primary/10">
              <div className="flex items-center gap-3 mb-3">
                <ShieldCheck className="text-medical-primary" size={20} />
                <span className="font-bold text-slate-900">Safe & Secure</span>
              </div>
              <p className="text-sm text-slate-600">
                Your data is only used to process your appointment. We follow strict medical privacy standards.
              </p>
            </div>
          </div>
          
          {/* Right Side: Form */}
          <div className="flex-1 w-full">
            <BookingForm />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Booking;
