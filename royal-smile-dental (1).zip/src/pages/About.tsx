import React from 'react';
import { motion } from 'motion/react';
import { Award, CheckCircle2, Heart, ShieldCheck, Users } from 'lucide-react';

const About = () => {
  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="bg-medical-accent/30 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-6">About Royal Smile Dental</h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Dedicated to providing the highest quality dental care in Paschim Vihar, West Delhi, with a focus on patient comfort and advanced clinical excellence.
          </p>
        </div>
      </section>

      {/* Dr. Profile */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1">
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-24 h-24 bg-medical-primary/10 rounded-full -z-10" />
                <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-medical-secondary/10 rounded-full -z-10" />
                <img 
                  src="https://picsum.photos/seed/doctor/600/700" 
                  alt="Dr. Ruchita Arora" 
                  className="rounded-3xl shadow-2xl w-full h-auto object-cover border-8 border-white"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            
            <div className="flex-1">
              <span className="text-medical-primary font-bold uppercase tracking-widest text-sm mb-4 block">Lead Dentist</span>
              <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-6">Meet Dr. Ruchita Arora</h2>
              <p className="text-slate-600 mb-6 leading-relaxed">
                Dr. Ruchita Arora is a highly skilled and compassionate dental surgeon with over 10 years of experience in clinical dentistry. She specializes in advanced restorative procedures, painless root canal treatments, and aesthetic smile makeovers.
              </p>
              <p className="text-slate-600 mb-8 leading-relaxed">
                Her philosophy is centered around "Patient-First" care, ensuring that every individual who walks into Royal Smile Dental feels heard, comfortable, and confident in their treatment plan. She stays at the forefront of dental technology to provide the most efficient and effective care possible.
              </p>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-medical-accent text-medical-primary rounded-lg flex items-center justify-center">
                    <Award size={20} />
                  </div>
                  <span className="font-bold text-slate-800">BDS, MDS</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-medical-accent text-medical-primary rounded-lg flex items-center justify-center">
                    <Users size={20} />
                  </div>
                  <span className="font-bold text-slate-800">10+ Years Exp.</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-4">Our Mission & Values</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              We are committed to excellence in every aspect of our practice, from the front desk to the dental chair.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Excellence",
                desc: "We strive for clinical perfection in every procedure, using the best materials and latest techniques.",
                icon: ShieldCheck
              },
              {
                title: "Compassion",
                desc: "We understand that dental visits can be stressful. We provide a gentle, caring environment for all.",
                icon: Heart
              },
              {
                title: "Integrity",
                desc: "Transparent pricing and honest treatment plans are the foundation of our patient relationships.",
                icon: CheckCircle2
              }
            ].map((item, i) => (
              <div key={i} className="bg-white p-10 rounded-2xl shadow-sm border border-slate-100 text-center">
                <div className="w-16 h-16 bg-medical-accent text-medical-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <item.icon size={32} />
                </div>
                <h3 className="text-xl font-display font-bold mb-4 text-slate-900">{item.title}</h3>
                <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1 order-2 lg:order-1">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-8">Why Choose Royal Smile Dental?</h2>
              <div className="space-y-6">
                {[
                  { title: "Advanced Technology", desc: "We use digital X-rays, rotary endodontics, and intraoral cameras for precise diagnosis." },
                  { title: "Strict Sterilization", desc: "Your safety is our priority. We follow international protocols for sterilization and hygiene." },
                  { title: "Painless Procedures", desc: "Specialized techniques and modern anesthesia ensure a comfortable experience." },
                  { title: "Affordable Care", desc: "Quality dental care shouldn't break the bank. We offer competitive pricing for all treatments." }
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1 w-6 h-6 bg-medical-primary text-white rounded-full flex items-center justify-center shrink-0">
                      <CheckCircle2 size={14} />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 mb-1">{item.title}</h4>
                      <p className="text-sm text-slate-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex-1 order-1 lg:order-2">
              <img 
                src="https://picsum.photos/seed/clinic/800/600" 
                alt="Modern Dental Equipment" 
                className="rounded-3xl shadow-xl w-full h-auto object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
