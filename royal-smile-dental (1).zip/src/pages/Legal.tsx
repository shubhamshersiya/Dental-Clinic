import React from 'react';
import { useLocation } from 'react-router-dom';

const Legal = () => {
  const location = useLocation();
  const isPrivacy = location.pathname === '/privacy-policy';

  return (
    <div className="pt-32 pb-24 bg-slate-50 min-h-screen">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="bg-white p-8 md:p-16 rounded-[40px] shadow-sm border border-slate-100">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-8">
            {isPrivacy ? 'Privacy Policy' : 'Terms & Conditions'}
          </h1>
          
          <div className="prose prose-slate max-w-none space-y-6 text-slate-600 leading-relaxed">
            {isPrivacy ? (
              <>
                <p className="font-bold text-slate-900">Last Updated: March 2024</p>
                <p>
                  At Royal Smile Dental, we are committed to protecting your privacy and ensuring the security of your personal and medical information. This Privacy Policy explains how we collect, use, and safeguard your data.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">1. Information We Collect</h3>
                <p>
                  We collect personal information when you book an appointment, including your name, phone number, email address, and dental history. This information is necessary to provide you with quality dental care.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">2. How We Use Your Information</h3>
                <p>
                  Your information is used solely for:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Scheduling and managing your appointments.</li>
                  <li>Providing personalized dental treatments.</li>
                  <li>Communicating with you regarding your dental health and follow-ups.</li>
                  <li>Improving our services and patient experience.</li>
                </ul>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">3. Data Security</h3>
                <p>
                  We implement strict security measures to protect your data from unauthorized access, disclosure, or alteration. Your medical records are stored securely and accessed only by authorized clinical staff.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">4. Sharing Your Information</h3>
                <p>
                  We do not sell or share your personal information with third parties for marketing purposes. We may share information with specialists or insurance providers only with your explicit consent.
                </p>
              </>
            ) : (
              <>
                <p className="font-bold text-slate-900">Last Updated: March 2024</p>
                <p>
                  Welcome to Royal Smile Dental. By accessing our website and using our services, you agree to comply with and be bound by the following terms and conditions.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">1. Appointment Booking</h3>
                <p>
                  Appointments booked through our website or WhatsApp are subject to availability. We reserve the right to reschedule appointments in case of emergencies or unforeseen circumstances.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">2. Cancellation Policy</h3>
                <p>
                  We request at least 24 hours' notice for any appointment cancellations or rescheduling. This allows us to offer the slot to other patients in need of care.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">3. Treatment Plans</h3>
                <p>
                  Treatment plans and cost estimates provided during consultation are based on the initial examination. Final costs may vary depending on the actual clinical findings during the procedure.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">4. Medical Accuracy</h3>
                <p>
                  The information provided on this website is for educational purposes and does not substitute professional medical advice. Always consult with a qualified dentist for diagnosis and treatment.
                </p>
                
                <h3 className="text-xl font-bold text-slate-900 mt-8">5. Limitation of Liability</h3>
                <p>
                  Royal Smile Dental and its staff shall not be liable for any indirect or consequential damages arising from the use of our website or services, beyond the scope of professional clinical liability.
                </p>
              </>
            )}
          </div>
          
          <div className="mt-12 pt-8 border-t border-slate-100">
            <p className="text-sm text-slate-500">
              If you have any questions regarding our {isPrivacy ? 'Privacy Policy' : 'Terms & Conditions'}, please contact us at <a href="mailto:shubhamshersiya99@gmail.com" className="text-medical-primary font-bold">shubhamshersiya99@gmail.com</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Legal;
