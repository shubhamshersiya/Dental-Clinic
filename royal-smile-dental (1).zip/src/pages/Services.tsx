import React from 'react';
import { motion } from 'motion/react';
import { Shield, CheckCircle2, MessageCircle, Phone, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useModal } from '../context/ModalContext';
import ServiceCard from '../components/ServiceCard';
import { ALL_SERVICES } from '../constants/services';

const Services = () => {
  const { openBookingModal } = useModal();

  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="bg-slate-900 py-24 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-medical-primary/10 blur-3xl rounded-full" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-display font-bold mb-6">Our Dental Services</h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            Comprehensive dental care for the whole family. We use the latest technology to ensure your comfort and the best clinical outcomes.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-4 mb-16">
            <div className="h-px w-16 md:w-32 bg-medical-primary" />
            <h2 className="text-3xl md:text-5xl font-display font-bold text-slate-900 whitespace-nowrap">Treatments</h2>
            <div className="h-px w-16 md:w-32 bg-medical-primary" />
          </div>
          
          <div className="flex overflow-x-auto pb-8 gap-6 snap-x snap-mandatory sm:grid sm:grid-cols-2 lg:grid-cols-5 sm:overflow-x-visible sm:pb-0 no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
            {ALL_SERVICES.map((service, idx) => (
              <div key={idx} className="min-w-[280px] sm:min-w-0 snap-center">
                <ServiceCard {...service} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pediatric Care Specialization */}
      <section className="py-24 bg-medical-accent/20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1">
              <span className="text-medical-primary font-bold uppercase tracking-widest text-sm mb-4 block">Specialized Care</span>
              <h2 className="text-3xl md:text-5xl font-display font-bold text-slate-900 mb-8 leading-tight">Gentle Pediatric Dentistry</h2>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                We understand that a child's first visit to the dentist sets the tone for their future oral health. Our clinic is designed to be child-friendly, ensuring a positive and stress-free experience for our youngest patients.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
                {[
                  "Child-Friendly Environment",
                  "Preventive Care & Sealants",
                  "Habit Counseling",
                  "Painless Treatments"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-medical-primary text-white rounded-full flex items-center justify-center shrink-0">
                      <CheckCircle2 size={12} />
                    </div>
                    <span className="text-slate-800 font-semibold">{item}</span>
                  </div>
                ))}
              </div>
              <button onClick={openBookingModal} className="btn-primary px-8 py-3">Book for Your Child</button>
            </div>
            <div className="flex-1">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <img 
                    src="https://images.unsplash.com/photo-1559599101-f09722fb4948?q=80&w=400&h=300&auto=format&fit=crop" 
                    className="rounded-2xl shadow-lg w-full h-48 object-cover" 
                    alt="Pediatric Care 2" 
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="space-y-4">
                  <img 
                    src="https://images.unsplash.com/photo-1609840114035-3c981b782dfe?q=80&w=600&h=800&auto=format&fit=crop" 
                    className="rounded-2xl shadow-lg w-full h-64 object-cover" 
                    alt="Pediatric Care 4" 
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Our Treatment Process</h2>
            <p className="text-slate-400 max-w-xl mx-auto">
              We follow a systematic approach to ensure you receive the most effective and personalized care.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Consultation", desc: "Thorough examination and digital diagnosis of your dental health." },
              { step: "02", title: "Treatment Plan", desc: "Personalized plan with transparent pricing and procedure details." },
              { step: "03", title: "Procedure", desc: "Expert clinical execution using advanced technology and gentle care." },
              { step: "04", title: "Aftercare", desc: "Detailed post-treatment instructions and follow-up to ensure healing." }
            ].map((item, i) => (
              <div key={i} className="relative">
                <div className="text-5xl font-display font-black text-white/10 mb-4">{item.step}</div>
                <h4 className="text-xl font-bold mb-2">{item.title}</h4>
                <p className="text-sm text-slate-400 leading-relaxed">{item.desc}</p>
                {i < 3 && <div className="hidden md:block absolute top-12 -right-4 w-8 h-px bg-white/20" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 text-center">
          <div className="bg-medical-accent rounded-[40px] p-12 md:p-20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-medical-primary/5 rounded-full -mr-32 -mt-32" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-medical-secondary/5 rounded-full -ml-32 -mb-32" />
            
            <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-6 relative z-10">Need a Specialized Treatment?</h2>
            <p className="text-lg text-slate-600 mb-10 max-w-2xl mx-auto relative z-10">
              Schedule a consultation with Dr. Ruchita Arora to discuss your specific dental needs and get a personalized treatment plan.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10">
              <button 
                onClick={openBookingModal}
                className="btn-primary px-10 py-4 text-lg w-full sm:w-auto"
              >
                Book Appointment
              </button>
              <Link to="/contact" className="btn-outline px-10 py-4 text-lg w-full sm:w-auto">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
