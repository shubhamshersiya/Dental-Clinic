import React from 'react';
import { MapPin, Phone, Mail, Clock, MessageCircle, Navigation } from 'lucide-react';

const Contact = () => {
  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-slate-900 py-20 text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">Contact Us</h1>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Have questions or need to find us? Here's all the information you need to get in touch with Royal Smile Dental.
          </p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 -mt-32 relative z-10">
            {/* Address */}
            <div className="bg-white p-10 rounded-3xl shadow-xl border border-slate-100 text-center">
              <div className="w-16 h-16 bg-medical-accent text-medical-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                <MapPin size={32} />
              </div>
              <h3 className="text-xl font-display font-bold mb-4 text-slate-900">Our Location</h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                Paschim Vihar, West Delhi
              </p>
              <a 
                href="https://maps.google.com/?q=Royal+Smile+Dental+Paschim+Vihar" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-medical-primary font-bold hover:underline flex items-center justify-center gap-2"
              >
                Open in Google Maps <Navigation size={16} />
              </a>
            </div>

            {/* Phone */}
            <div className="bg-white p-10 rounded-3xl shadow-xl border border-slate-100 text-center">
              <div className="w-16 h-16 bg-medical-accent text-medical-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Phone size={32} />
              </div>
              <h3 className="text-xl font-display font-bold mb-4 text-slate-900">Call or WhatsApp</h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                Available for appointments and emergency dental consultations.
              </p>
              <div className="flex flex-col gap-2">
                <a href="tel:7838406641" className="text-2xl font-display font-bold text-slate-900 hover:text-medical-primary transition-colors">
                  78384 06641
                </a>
                <a 
                  href="https://wa.me/917838406641" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-medical-secondary font-bold hover:underline flex items-center justify-center gap-2"
                >
                  Chat on WhatsApp <MessageCircle size={16} />
                </a>
              </div>
            </div>

            {/* Hours */}
            <div className="bg-white p-10 rounded-3xl shadow-xl border border-slate-100 text-center">
              <div className="w-16 h-16 bg-medical-accent text-medical-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Clock size={32} />
              </div>
              <h3 className="text-xl font-display font-bold mb-4 text-slate-900">Working Hours</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-500">Mon - Sat</span>
                  <span className="font-bold text-slate-900">10:00 AM - 8:00 PM</span>
                </div>
                <div className="flex justify-between pt-2">
                  <span className="text-slate-500">Sunday</span>
                  <span className="font-bold text-red-500">Closed</span>
                </div>
              </div>
              <p className="mt-6 text-xs text-slate-400 italic">
                *Emergency visits by appointment only.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Map Embed */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="bg-white p-4 rounded-[40px] shadow-sm border border-slate-100 overflow-hidden h-[500px]">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3500.865666756855!2d77.0945!3d28.6635!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d039566666667%3A0x6666666666666666!2sRoyal%20Smile%20Dental!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy"
              title="Royal Smile Dental Location"
            ></iframe>
          </div>
        </div>
      </section>

      {/* FAQ / Help */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-display font-bold text-slate-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-slate-600">Quick answers to common questions about our clinic.</p>
          </div>
          
          <div className="space-y-6">
            {[
              { q: "Is there parking available?", a: "Yes, street parking is available near the clinic. We are located on the upper ground floor for easy access." },
              { q: "Do you accept dental insurance?", a: "We accept most major dental insurance plans. Please bring your card during your visit for verification." },
              { q: "How can I reschedule my appointment?", a: "You can easily reschedule by messaging us on WhatsApp or calling our clinic number at least 24 hours in advance." }
            ].map((item, i) => (
              <div key={i} className="p-6 rounded-2xl border border-slate-100 bg-slate-50/50">
                <h4 className="font-bold text-slate-900 mb-2">{item.q}</h4>
                <p className="text-sm text-slate-600 leading-relaxed">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
