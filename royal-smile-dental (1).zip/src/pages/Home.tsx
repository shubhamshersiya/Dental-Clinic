import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Star, ShieldCheck, Clock, Award, Users, MessageCircle, Zap, Stethoscope, Trash2, Crown, Sparkles, Shield, HeartPulse, Microscope, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useModal } from '../context/ModalContext';
import ServiceCard from '../components/ServiceCard';
import TestimonialCard from '../components/TestimonialCard';
import BookingForm from '../components/BookingForm';
import { ALL_SERVICES } from '../constants/services';

const Home = () => {
  const { openBookingModal } = useModal();
  
  const testimonials = [
    {
      name: "Avinash Kumar",
      rating: 5,
      text: "Dr. Ruchita is very professional and patient. The RCT was completely painless. Highly recommended!",
      date: "2 months ago"
    },
    {
      name: "Dipti Sharma",
      rating: 5,
      text: "Best dental clinic in Paschim Vihar. The staff is friendly and the clinic is very clean.",
      date: "1 month ago"
    },
    {
      name: "Deepanshu Gupta",
      rating: 5,
      text: "Got my wisdom tooth removed here. The procedure was quick and the recovery was smooth.",
      date: "3 weeks ago"
    }
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-medical-accent/50 -z-10 rounded-bl-[100px] hidden lg:block" />
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-medical-primary/5 rounded-full blur-3xl -z-10" />
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="flex-1 text-center lg:text-left"
            >
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-2 bg-medical-accent text-medical-primary rounded-full text-sm font-bold mb-6"
              >
                <Star size={16} className="fill-medical-primary" />
                <span>Top-Rated Dental Clinic in Delhi</span>
              </motion.div>
              <h1 className="text-4xl md:text-5xl lg:text-7xl font-display font-bold text-slate-900 leading-[1.1] mb-6">
                Experience <span className="text-medical-primary">World-Class</span> Dental Excellence
              </h1>
              <p className="text-lg text-slate-600 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                Led by Dr. Ruchita Arora, we provide advanced, painless dental treatments with a gentle touch. Your comfort and health are our top priorities.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                <button 
                  onClick={openBookingModal}
                  className="btn-primary w-full sm:w-auto px-10 py-4 text-lg shadow-lg shadow-medical-primary/20"
                >
                  Book Appointment
                </button>
                <Link to="/services" className="btn-outline w-full sm:w-auto px-10 py-4 text-lg">
                  Explore Services
                </Link>
              </div>
              
              <div className="mt-12 flex items-center justify-center lg:justify-start gap-8">
                <div className="flex flex-col">
                  <span className="text-3xl font-bold text-slate-900">10+</span>
                  <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">Years Exp.</span>
                </div>
                <div className="w-px h-12 bg-slate-200" />
                <div className="flex flex-col">
                  <span className="text-3xl font-bold text-slate-900">5k+</span>
                  <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">Patients</span>
                </div>
                <div className="w-px h-12 bg-slate-200" />
                <a 
                  href="https://www.google.com/search?q=Royal+Smile+Dental+Paschim+Vihar#lrd=0x390d037666666667:0x6666666666666666,1" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex flex-col hover:text-medical-primary transition-colors cursor-pointer"
                >
                  <span className="text-3xl font-bold text-slate-900">4.9</span>
                  <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">Rating</span>
                </a>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="flex-1 relative"
            >
              <div className="relative z-10 rounded-[40px] overflow-hidden shadow-2xl border-[12px] border-white">
                <img 
                  src="https://picsum.photos/seed/dentist-hero/800/900" 
                  alt="Royal Smile Dental Clinic" 
                  className="w-full h-auto object-cover aspect-[4/5]"
                  referrerPolicy="no-referrer"
                />
              </div>
              
              {/* Floating Elements */}
              <motion.div 
                animate={{ y: [0, -15, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -bottom-8 -left-8 z-20 bg-white p-6 rounded-3xl shadow-2xl border border-slate-100 hidden md:block"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                    <ShieldCheck size={32} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">100% Safe</h4>
                    <p className="text-xs text-slate-500">Sterilized Equipment</p>
                  </div>
                </div>
              </motion.div>

              <motion.div 
                animate={{ y: [0, 15, 0] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="absolute top-12 -right-8 z-20 bg-white p-5 rounded-3xl shadow-2xl border border-slate-100 hidden md:block"
              >
              <a 
                href="https://www.google.com/search?q=Royal+Smile+Dental+Paschim+Vihar#lrd=0x390d037666666667:0x6666666666666666,1" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3 hover:opacity-80 transition-opacity cursor-pointer"
              >
                <div className="flex -space-x-3">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white overflow-hidden">
                      <img src={`https://i.pravatar.cc/100?u=${i}`} alt="User" />
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">177+ Reviews</p>
                  <div className="flex text-yellow-400">
                    {[1, 2, 3, 4, 5].map(i => <Star key={i} size={10} fill="currentColor" />)}
                  </div>
                </div>
              </a>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>


      {/* All Services Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-4 mb-16">
            <div className="h-px w-16 md:w-32 bg-medical-primary" />
            <h2 className="text-3xl md:text-5xl font-display font-bold text-slate-900 whitespace-nowrap">Treatments</h2>
            <div className="h-px w-16 md:w-32 bg-medical-primary" />
          </div>
          
          <div className="flex overflow-x-auto pb-8 gap-6 snap-x snap-mandatory sm:grid sm:grid-cols-2 lg:grid-cols-5 sm:overflow-x-visible sm:pb-0 no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
            {ALL_SERVICES.map((service, idx) => (
              <div key={idx} className="min-w-[280px] sm:min-w-0 snap-center">
                <ServiceCard {...service} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Banner */}
      <section className="py-16 bg-medical-primary text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl md:text-5xl font-display font-bold mb-2">5000+</div>
              <div className="text-white/70 text-sm font-medium uppercase tracking-widest">Happy Patients</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-display font-bold mb-2">10+</div>
              <div className="text-white/70 text-sm font-medium uppercase tracking-widest">Years Experience</div>
            </div>
            <a 
              href="https://www.google.com/search?q=Royal+Smile+Dental+Paschim+Vihar#lrd=0x390d037666666667:0x6666666666666666,1" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:opacity-80 transition-opacity cursor-pointer"
            >
              <div className="text-4xl md:text-5xl font-display font-bold mb-2">177+</div>
              <div className="text-white/70 text-sm font-medium uppercase tracking-widest">Google Reviews</div>
            </a>
            <div>
              <div className="text-4xl md:text-5xl font-display font-bold mb-2">100%</div>
              <div className="text-white/70 text-sm font-medium uppercase tracking-widest">Satisfaction</div>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-medical-accent/20 -z-10 skew-y-3 origin-top-left" />
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1">
              <h2 className="text-3xl md:text-5xl font-display font-bold text-slate-900 mb-8 leading-tight">Take the First Step to a Healthier Smile</h2>
              <p className="text-lg text-slate-600 mb-10 leading-relaxed">
                Schedule your consultation today. Our team is ready to provide you with a personalized treatment plan and the care you deserve.
              </p>
              
              <div className="space-y-6 mb-10">
                {[
                  "Instant Booking via WhatsApp",
                  "Painless Treatment Options",
                  "Flexible Appointment Timings",
                  "Expert Consultation"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <div className="w-6 h-6 bg-medical-primary text-white rounded-full flex items-center justify-center shrink-0">
                      <CheckCircle2 size={14} />
                    </div>
                    <span className="text-slate-800 font-semibold">{item}</span>
                  </div>
                ))}
              </div>
              
              <div className="flex items-center gap-6 p-6 bg-white rounded-[32px] shadow-xl border border-slate-100">
                <div className="w-16 h-16 bg-medical-primary text-white rounded-2xl flex items-center justify-center shadow-lg shadow-medical-primary/30">
                  <MessageCircle size={32} />
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-widest font-bold mb-1">Direct WhatsApp</p>
                  <p className="text-xl font-bold text-slate-900">78384 06641</p>
                </div>
              </div>
            </div>
            
            <div className="flex-1 w-full">
              <BookingForm 
                title="Schedule Appointment" 
                subtitle="Fill the form to get an instant WhatsApp confirmation."
                compact
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-display font-bold text-slate-900 mb-4">Patient Success Stories</h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">
              We take pride in the smiles we've restored. Here's what our patients have to say about their experience.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <TestimonialCard key={i} {...t} />
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <a 
              href="https://www.google.com/search?q=Royal+Smile+Dental+Paschim+Vihar#lrd=0x390d037666666667:0x6666666666666666,1" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-8 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-900 hover:bg-slate-50 transition-all shadow-sm"
            >
              <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
              View All 177+ Google Reviews
              <ArrowRight size={18} />
            </a>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-24 bg-slate-900 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-medical-primary/10 blur-3xl rounded-full" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-6xl font-display font-bold text-white mb-8 leading-tight">Ready to Transform Your Smile?</h2>
            <p className="text-xl text-slate-400 mb-12">
              Join thousands of happy patients at Royal Smile Dental. Book your appointment today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <button 
                onClick={openBookingModal}
                className="btn-primary w-full sm:w-auto px-12 py-5 text-xl"
              >
                Book Appointment
              </button>
              <a href="tel:7838406641" className="w-full sm:w-auto px-12 py-5 rounded-xl border-2 border-white/20 text-white font-bold text-xl hover:bg-white/10 transition-all flex items-center justify-center gap-3">
                <Phone size={24} /> 78384 06641
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

const Phone = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
  </svg>
);

export default Home;
