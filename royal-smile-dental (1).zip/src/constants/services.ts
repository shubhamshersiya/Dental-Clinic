export const ALL_SERVICES = [
  {
    title: "Invisalign",
    hoverTitle: "Perfect alignment that shines",
    description: "Clear, removable aligners for a straighter smile without braces. Comfortable, discreet, and effective.",
    image: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.1
  },
  {
    title: "Implant Dentistry",
    hoverTitle: "Permanent tooth replacement",
    description: "Permanent tooth replacement that looks, feels, and functions like natural teeth for long-lasting oral health.",
    image: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.2
  },
  {
    title: "Cosmetic Dentistry",
    hoverTitle: "Aesthetic smile makeover",
    description: "Transform your smile with veneers, whitening, and aesthetic bonding for a perfect, confident look.",
    image: "https://images.unsplash.com/photo-1598256989800-fe5f95da9787?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.3
  },
  {
    title: "General Dentistry",
    hoverTitle: "Comprehensive oral care",
    description: "Comprehensive routine care, checkups, and cleanings to maintain your oral health and prevent future issues.",
    image: "https://images.unsplash.com/photo-1460672985063-6764ac8b9c74?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.5
  },
  {
    title: "Root Canal (RCT)",
    hoverTitle: "Painless tooth saving",
    description: "Advanced rotary RCT techniques to save your natural teeth from infection with minimal discomfort.",
    image: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.1
  },
  {
    title: "Teeth Whitening",
    hoverTitle: "Brighter, whiter smile",
    description: "Professional whitening treatments that remove deep stains and brighten your smile in just one visit.",
    image: "https://images.unsplash.com/photo-1559599101-f09722fb4948?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.2
  },
  {
    title: "Pediatric Dentistry",
    hoverTitle: "Gentle care for kids",
    description: "Specialized dental care for children in a friendly, comfortable environment to build healthy habits early.",
    image: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.3
  },
  {
    title: "Wisdom Tooth",
    hoverTitle: "Expert surgical removal",
    description: "Safe and comfortable extraction of impacted wisdom teeth to prevent pain and crowding of other teeth.",
    image: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.4
  },
  {
    title: "Bridges & Crowns",
    hoverTitle: "Restorative excellence",
    description: "High-quality ceramic crowns and bridges to restore the strength and appearance of damaged or missing teeth.",
    image: "https://images.unsplash.com/photo-1606811971618-4486d14f3f99?q=80&w=600&h=800&auto=format&fit=crop",
    delay: 0.5
  }
];
