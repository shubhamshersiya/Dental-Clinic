import { LucideIcon } from 'lucide-react';

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  details: string;
}

export interface Testimonial {
  id: string;
  name: string;
  rating: number;
  text: string;
  date: string;
}

export interface BookingData {
  fullName: string;
  phoneNumber: string;
  service: string;
  date: string;
  time: string;
  message: string;
}
